-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 31, 2022 at 04:48 AM
-- Server version: 8.0.30
-- PHP Version: 7.4.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_commerce_node`
--

-- --------------------------------------------------------

--
-- Table structure for table `child_catagories`
--

CREATE TABLE `child_catagories` (
  `id` int NOT NULL,
  `sub_catagory_id` int DEFAULT NULL,
  `child_catagory_title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `child_catagories`
--

INSERT INTO `child_catagories` (`id`, `sub_catagory_id`, `child_catagory_title`, `image`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'Fresh Vegetables', 'fresh-vegetables.png', '2022-10-30 04:49:10', '2022-10-30 04:49:10'),
(2, 1, 'Fresh Fruits', 'fresh-fruits.png', '2022-10-30 04:49:10', '2022-10-30 04:49:10'),
(3, 2, 'Chicken & Poultry', 'chicken-poultry.png', '2022-10-31 04:41:12', '2022-10-31 04:41:12'),
(4, 2, 'Frozen Fish', 'frozen-fish.png', '2022-10-31 04:41:12', '2022-10-31 04:41:12'),
(5, 2, 'Meat', 'meat.png', '2022-10-31 04:41:12', '2022-10-31 04:41:12'),
(6, 2, 'Tofu & Meat Alternatives', 'tofu-meat-alternatives.png', '2022-10-31 04:41:12', '2022-10-31 04:41:12'),
(7, 2, 'Dried Fish', 'dried-fish.png', '2022-10-31 04:41:12', '2022-10-31 04:41:12');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `child_catagory_id` int DEFAULT NULL,
  `product_title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `discounted_price` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `rating` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `child_catagory_id`, `product_title`, `image`, `price`, `discounted_price`, `quantity`, `rating`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'Deshi Peyaj (Local Onion) ± 50 gm', 'deshi-peyaj-local-onion-50-gm-1-kg.png', '59', '55', '1 kg', '4.46', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(2, 1, 'Potato Regular (± 50 gm)', 'potato-regular-50-gm-1-kg.png', '40', '30', '1 kg', '3.56', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(3, 1, 'Boro Alu (Big Diamond Potato) ± 50 gm', 'boro-alu-big-diamond-potato-50-gm-1-kg.png', '40', '31', '1 kg', '3.12', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(4, 1, 'Kacha Morich (Green Chilli) ±12 gm', 'kacha-morich-green-chilli-12-gm-250-gm.png', '30', '19', '250 gm', '3.29', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(5, 1, 'Coriander Leaves (Dhonia Pata) ± 10 gm', 'coriander-leaves-dhonia-pata-10-gm-100-gm.png', '29', '19', '100 gm', '4.89', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(6, 1, 'Red Tomato ± 25 gm', 'red-tomato-25-gm-500-gm.png', '79', '69', '500 gm', '3.50', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(7, 1, 'Roshun (Garlic Imported) ± 25 gm', 'roshun-garlic-imported-25-gm-500-gm.png', '75', '65', '500 gm', '4.14', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(8, 1, 'Potol (Pointed Gourd) ± 25 gm', 'potol-pointed-gourd-25-gm-500-gm.png', '35', '29', '500 gm', '3.34', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(9, 1, 'Peyaj (Onion Imported) Special Offer ± 100 gm', 'peyaj-onion-imported-special-offer-100-gm-3-kg.png', '165', '149', '3 kg', '4.81', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(10, 1, 'Dheros (Ladies Finger) ± 25 gm', 'dheros-ladies-finger-25-gm-500-gm.png', '35', '29', '500 gm', '3.88', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(11, 1, 'Lal Peyaj (Onion Red Imported) ± 50 gm', 'lal-peyaj-onion-red-imported-50-gm-1-kg.png', '60', '55', '1 kg', '4.56', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(12, 1, 'Ada (Imported Ginger) ± 25 gm', 'ada-imported-ginger-25-gm-500-gm.png', '100', '79', '500 gm', '3.46', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(13, 1, 'Deshi Shosha (Local Cucumber) ± 25 gm', 'deshi-shosha-local-cucumber-25-gm-500-gm.png', '50', '39', '500 gm', '3.29', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(14, 1, 'Lal Shak (Red Spinach)', 'lal-shak-red-spinach-1-bundle.png', '25', '', '1 bundle', '4.22', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(15, 1, 'Kacha Pepe (Green Papaya) ± 70 gm', 'kacha-pepe-green-papaya-70-gm-14-kg.png', '49', '39', '1.4 kg', '4.41', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(16, 1, 'Lomba Lebu (Long Lemon)', 'lomba-lebu-long-lemon-4-pcs.png', '35', '29', '4 pcs', '4.57', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(17, 1, 'Misti Kumra Fali (Sweet Pumpkin Slice) ± 40 gm', 'misti-kumra-fali-sweet-pumpkin-slice-40-gm-1-kg.png', '49', '45', '1 kg', '3.21', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(18, 1, 'Lal Alu (Red Potato Cardinal) ± 50 gm', 'lal-alu-red-potato-cardinal-50-gm-1-kg.png', '40', '35', '1 kg', '3.93', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(19, 1, 'Kolmi Shak (Water Spinach)', 'kolmi-shak-water-spinach-1-bundle.png', '25', '15', '1 bundle', '4.25', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(20, 1, 'Fulkopi (Cauliflower)', 'fulkopi-cauliflower-1-pcs.png', '65', '49', 'each', '3.30', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(21, 1, 'Deshi Roshun (Garlic Local) ±25 gm', 'deshi-roshun-garlic-local-25-gm-500-gm.png', '65', '55', '500 gm', '3.82', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(22, 1, 'Gajor (Imported Carrot) ± 30 gm', 'gajor-imported-carrot-30-gm-600-gm.png', '99', '89', '600 gm', '3.45', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(23, 1, 'Deshi Ada (Local Ginger) ± 25 gm', 'deshi-ada-local-ginger-25-gm-500-gm.png', '85', '75', '500 gm', '3.65', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(24, 1, 'Chichinga (Snake Gourd) ± 25 gm', 'chichinga-snake-gourd-25-gm-500-gm.png', '35', '', '500 gm', '4.31', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(25, 1, 'Shosha (Cucumber) ± 25 gm', 'shosha-cucumber-25-gm-500-gm.png', '40', '35', '500 gm', '4.66', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(26, 1, 'Borboti (Long Bean) ± 25 gm', 'borboti-long-bean-25-gm-500-gm.png', '45', '39', '500 gm', '3.05', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(27, 1, 'Green Capsicum ± 15 gm', 'green-capsicum-15-gm-300-gm.png', '135', '89', '300 gm', '4.93', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(28, 1, 'Lomba Kalo Begun (Long Brinjal Black) ± 25 gm', 'lomba-kalo-begun-long-brinjal-black-25-gm-500-gm.png', '39', '35', '500 gm', '4.54', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(29, 1, 'Gol Lebu (Round Lemon)', 'gol-lebu-round-lemon-4-pcs.png', '40', '29', '4 pcs', '4.47', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(30, 1, 'Kochur Mukhi (Taro Roots) ± 25 gm', 'kochur-mukhi-taro-roots-25-gm-500-gm.png', '40', '35', '500 gm', '4.92', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(31, 1, 'Dhundhul (Sponge Gourd) ±20 gm', 'dhundhul-sponge-gourd-20-gm-500-gm.png', '40', '35', '500 gm', '4.10', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(32, 1, 'Lau (Bottle Gourd)', 'lau-bottle-gourd-1-pcs.png', '75', '65', 'each', '4.51', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(33, 1, 'Palong Shak (Palong Spinach)', 'palong-shak-palong-spinach-1-bundle.png', '35', '29', '1 bundle', '3.89', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(34, 1, 'Uchche (Local Bitter Gourd) ± 25 gm', 'uchche-local-bitter-gourd-25-gm-500-gm.png', '55', '45', '500 gm', '4.60', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(35, 1, 'Kalo Gol Begun (Round Brinjals Black) ±35 gm', 'kalo-gol-begun-round-brinjals-black-35-gm-700-gm.png', '85', '65', '700 gm', '4.29', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(36, 1, 'Korola (Bitter Gourd) ± 25 gm', 'korola-bitter-gourd-25-gm-500-gm.png', '45', '39', '500 gm', '3.76', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(37, 1, 'Kagozi Lebu (Kagozi Lemon)', 'kagozi-lebu-kagozi-lemon-4-pcs.png', '40', '29', '4 pcs', '4.64', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(38, 1, 'Kacha Kola (Banana Green)', 'kacha-kola-banana-green-4-pcs.png', '45', '39', '4 pcs', '4.60', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(39, 1, 'Pui Shak (Pui Spinach)', 'pui-shak-pui-spinach-1-bundle.png', '40', '29', '1 bundle', '4.59', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(40, 1, 'Lal Alu (Red Potato) ± 25 gm', 'lal-alu-red-potato-25-gm-500-gm.png', '25', '20', '500 gm', '4.25', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(41, 1, 'Jali Kumra (Water Pumpkin)', 'jali-kumra-water-pumpkin-1-pcs.png', '55', '49', 'each', '4.50', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(42, 1, 'Kakrol (Sweet Bitter Gourd) ±25 gm', 'kakrol-sweet-bitter-gourd-25-gm-500-gm.png', '39', '', '500 gm', '3.52', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(43, 1, 'Sobuj Gol Begun (Round Brinjals Green) ±35 gm', 'sobuj-gol-begun-round-brinjals-green-35-gm-700-gm.png', '75', '55', '700 gm', '4.33', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(44, 1, 'Jhinga (Ridge Gourd) ±20 gm', 'jhinga-ridge-gourd-20-gm-500-gm.png', '39', '', '500 gm', '3.41', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(45, 1, 'Kochur Loti (Stolon Of Taro) ± 25 gm', 'kochur-loti-stolon-of-taro-25-gm-500-gm.png', '39', '', '500 gm', '3.83', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(46, 1, 'Data Shak (Data Spinach)', 'data-shak-data-spinach-1-bundle.png', '25', '19', '1 bundle', '3.90', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(47, 1, 'Mula (Radish) ± 25 gm', 'mula-radish-25-gm-500-gm.png', '40', '35', '500 gm', '4.28', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(48, 1, 'Pudina Pata (Mint Leaves) ± 10 gm', 'pudina-pata-mint-leaves-10-gm-100-gm.png', '99', '35', '100 gm', '3.91', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(49, 1, 'Mula Shak (Radish Spinach)', 'mula-shak-radish-spinach-1-bundle.png', '35', '19', '1 bundle', '4.61', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(50, 1, 'Beetroot ±25 gm', 'beetroot-25-gm-500-gm.png', '125', '85', '500 gm', '3.62', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(51, 1, 'Pat Shak (Jute Spinach)', 'pat-shak-jute-spinach-1-bundle.png', '25', '19', '1 bundle', '4.13', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(52, 1, 'Bombay Chilli', 'bombay-chilli-5-pcs.png', '35', '29', '5 pcs', '4.34', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(53, 1, 'Lettuce Leaves ± 10 gm', 'lettuce-leaves-10-gm-100-gm.png', '109', '45', '100 gm', '3.62', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(54, 1, 'Lau Shak (Sweet Bitter Melon Leaves)', 'lau-shak-sweet-bitter-melon-leaves-1-bundle.png', '55', '39', '1 bundle', '4.73', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(55, 1, 'Peyaj Pata (Spring Onion) ± 12 gm', 'peyaj-pata-spring-onion-12-gm-250-gm.png', '85', '55', '250 gm', '3.87', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(56, 1, 'Thankuni Pata (Pennywort Leaves)', 'thankuni-pata-pennywort-leaves-1-bundle.png', '19', '9', '1 bundle', '3.95', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(57, 1, 'Misti Kumra (Sweet Pumpkin)', 'misti-kumra-sweet-pumpkin-1-pcs.png', '100', '95', 'each', '3.42', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(58, 1, 'Flat Bean (Sheem)', 'flat-bean-sheem-500-gm.png', '79', '55', '500 gm', '4.28', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(59, 1, 'Red Capsicum ±12 gm', 'red-capsicum-12-gm-250-gm.png', '209', '125', '250 gm', '3.99', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(60, 1, 'Kacha Holud (Raw Turmeric) ± 12 gm', 'kacha-holud-raw-turmeric-12-gm-250-gm.png', '55', '45', '250 gm', '4.48', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(61, 1, 'Aloe Vera', 'aloe-vera-1-pcs.png', '50', '35', 'each', '4.50', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(62, 1, 'Bok Choy', 'bok-choy-250-gm.png', '75', '', '250 gm', '3.41', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(63, 1, 'Baby Corn ± 25 gm', 'baby-corn-25-gm-550-gm.png', '160', '129', '550 gm', '3.05', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(64, 1, 'Ol Kochu (Elephant Foot Yam) ± 25 gm', 'ol-kochu-elephant-foot-yam-25-gm-500-gm.png', '45', '39', '500 gm', '3.62', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(65, 1, 'Paan (Betel Leaf) Half Bira', 'paan-betel-leaf-half-bira-30-pcs.png', '59', '49', '30 pcs', '3.22', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(66, 1, 'Jaam Alu (Small Potato) ± 50 gm', 'jaam-alu-small-potato-50-gm-1-kg.png', '79', '59', '1 kg', '3.61', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(67, 1, 'Lemon Grass Stalk ± 12 gm', 'lemon-grass-stalk-12-gm-250-gm.png', '105', '59', '250 gm', '4.32', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(68, 1, 'Lomba Kochu', 'lomba-kochu-1-pcs.png', '79', '', 'each', '4.05', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(69, 1, 'Banana Flower (Kolar Mocha)', 'banana-flower-kolar-mocha-1-pcs.png', '60', '49', 'each', '3.78', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(70, 1, 'Yellow Capsicum ±15 gm', 'yellow-capsicum-15-gm-300-gm.png', '249', '149', '300 gm', '5.00', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(71, 1, 'Badhakopi Pata (Chinese Cabbage Leaves) 150gm+', 'badhakopi-pata-chinese-cabbage-leaves-150gm-1pcs.png', '50', '45', 'each', '3.80', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(72, 1, 'Mehendi Pata (Henna Leaves)', 'mehendi-pata-henna-leaves-3-bundles.png', '60', '49', '3 bundles', '4.41', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(73, 1, 'Thai Ada (Ginger Thai) ± 12 gm', 'thai-ada-ginger-thai-12-gm-250-gm.png', '125', '69', '250 gm', '3.12', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(74, 1, 'Lomba Sheem (Mou Sheem)', 'lomba-sheem-mou-sheem-500-gm.png', '60', '45', '500 gm', '3.38', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(75, 1, 'Mete Alu (Mud Potato) ± 25 gm', 'mete-alu-mud-potato-25-gm-500-gm.png', '45', '', '500 gm', '3.12', '2022-10-30 05:02:26', '2022-10-30 05:02:26'),
(76, 2, 'Shagor Kola (Banana Sagor)', 'shagor-kola-banana-sagor-4-pcs.png', '45', '', '4 pcs', '4.95', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(77, 2, 'Banana Chompa (Ready To Eat)', 'banana-chompa-ready-to-eat-4-pcs.png', '32', '25', '4 pcs', '4.09', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(78, 2, 'Daab (Green Coconut)', 'daab-green-coconut-1-pcs.png', '119', '105', 'each', '4.68', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(79, 2, 'Malta ± 50 gm', 'malta-50-gm-1-kg.png', '249', '209', '1 kg', '3.35', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(80, 2, 'Guava Premium (± 50 gm)', 'guava-premium-50-gm-1-kg.png', '95', '79', '1 kg', '4.46', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(81, 2, 'Banana Sobri', 'banana-sobri-4-pcs.png', '55', '39', '4 pcs', '4.91', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(82, 2, 'Lal Angur (Red Grapes) ± 12 gm', 'lal-angur-red-grapes-12-gm-250-gm.png', '109', '95', '250 gm', '4.88', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(83, 2, 'Green Apple ± 50 gm', 'green-apple-50-gm-1-kg.png', '335', '289', '1 kg', '4.39', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(84, 2, 'Bangla Kola', 'bangla-kola-4-pcs.png', '39', '35', '4 pcs', '4.68', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(85, 2, 'Anaros (Pineapple)', 'anaros-pineapple-1-pcs.png', '99', '65', 'each', '4.88', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(86, 2, 'Paka Pape ± 50 gm', 'paka-pape-50-gm-1-kg.png', '129', '89', '1 kg', '4.94', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(87, 2, 'Amra (Hog Plum) ± 50 gm', 'amra-hog-plum-50-gm-1-kg.png', '85', '65', '1 kg', '4.84', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(88, 2, 'Gala Apple ± 50 gm', 'gala-apple-50-gm-1-kg.png', '299', '289', '1 kg', '4.59', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(89, 2, 'Dalim (Pomegranate)', 'dalim-pomegranate-2-pcs.png', '300', '269', '2 pcs', '3.15', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(90, 2, 'Jambura (Pomelo)', 'jambura-pomelo-1-pcs.png', '109', '', 'each', '4.03', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(91, 2, 'China Fuji Apple ± 50 gm', 'china-fuji-apple-50-gm-1-kg.png', '299', '', '1 kg', '3.59', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(92, 2, 'Narikel (Coconut)', 'narikel-coconut-1-pcs.png', '129', '99', 'each', '4.86', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(93, 2, 'Dragon Fruit Local (± 50 gm)', 'dragon-fruit-local-50-gm-1-kg.png', '459', '389', '1 kg', '3.10', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(94, 2, 'Shada Nashpati (Pear White)', 'shada-nashpati-pear-white-2-pcs.png', '179', '159', '2 pcs', '4.63', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(95, 2, 'Wood Apple (Kodbel)', 'wood-apple-kodbel-1-pcs.png', '60', '49', 'each', '4.72', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(96, 2, 'Komola (Orange) Imported ± 50 gm', 'komola-orange-imported-50-gm-1-kg.png', '369', '349', '1 kg', '4.30', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(97, 2, 'Amloki (Amla) ± 12 gm', 'amloki-amla-12-gm-250-gm.png', '80', '55', '250 gm', '4.20', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(98, 2, 'Chalta', 'chalta-1-pcs.png', '39', '25', 'each', '3.31', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(99, 2, 'Sobuj Nashpati (Pear Green)', 'sobuj-nashpati-pear-green-2-pcs.png', '179', '', '2 pcs', '3.43', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(100, 2, 'Green Olives (Jolpai) ± 25 gm', 'green-olives-jolpai-25-gm-500-gm.png', '59', '45', '500 gm', '4.47', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(101, 2, 'EZ Daab (Prime Coconut)', 'ez-daab-prime-coconut-1-pcs.png', '120', '', 'each', '4.54', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(102, 2, 'Avocado Fruit 470 gm (Net Weight ± 50 gm)', 'avocado-fruit-470-gm-net-weight-50-gm-2-pcs.png', '649', '', '2 pcs', '3.01', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(103, 2, 'Australian Apple (± 50 gm)', 'australian-apple-50-gm-1-kg.png', '250', '229', '1 kg', '4.21', '2022-10-30 05:03:43', '2022-10-30 05:03:43'),
(104, 3, 'Broiler Chicken Skin Off ± 50 gm', 'broiler-chicken-skin-off-50-gm-1-kg.png', '329', '309', '1 kg', '4.14', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(105, 3, 'Cock Chicken Skin Off ± 25 gm', 'cock-chicken-skin-off-25-gm-500-gm.png', '315', '309', '500 gm', '3.69', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(106, 3, 'Broiler Chicken Skin On ± 50 gm', 'broiler-chicken-skin-on-50-gm-1-kg.png', '315', '279', '1 kg', '3.82', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(107, 3, 'Roast Chicken ± 10 gm', 'roast-chicken-10-gm-275-gm.png', '189', '179', '275 gm', '4.88', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(108, 3, 'Bengal Meat Whole Chicken Curry Cut ± 50 gm', 'bengal-meat-whole-chicken-curry-cut-50-gm-1-kg.png', '350', '', '1 kg', '4.37', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(109, 3, 'Pigeon Meat', 'pigeon-meat-1-pcs.png', '169', '159', 'each', '4.21', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(110, 3, 'Whole Deshi Chicken Skin Off ± 25 gm', 'whole-deshi-chicken-skin-off-25-gm-500-gm.png', '479', '449', '500 gm', '3.91', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(111, 3, 'Whole Deshi Duck (Hash) With Skin', 'whole-deshi-duck-hash-with-skin-900-gm.png', '599', '519', '900 gm', '4.89', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(112, 3, 'Chicken Liver Gizzard Mix', 'chicken-liver-gizzard-mix-1-kg.png', '249', '229', '1 kg', '4.70', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(113, 3, 'Whole Layer Chicken Skin Off (Net Weight ± 50 gm)', 'whole-layer-chicken-skin-off-net-weight-50-gm-800-gm.png', '529', '459', '800 gm', '3.63', '2022-10-31 04:42:43', '2022-10-31 04:42:43'),
(114, 4, 'Horina Chingri (Shrimp) 35-40 pcs ±15 gm', 'horina-chingri-shrimp-35-40-pcs-15-gm-250-gm.png', '185', '165', '250 gm', '3.75', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(115, 4, 'Bagda Chingri (Shrimp) 25-30 pcs ±30 gm', 'bagda-chingri-shrimp-25-30-pcs-30-gm-500-gm.png', '419', '355', '500 gm', '3.24', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(116, 4, 'Pabda Fish ±30 gm', 'pabda-fish-30-gm-500-gm.png', '249', '219', '500 gm', '4.53', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(117, 4, 'Pangas Fish After Cutting ±50 gm', 'pangas-fish-after-cutting-50-gm-1-kg.png', '269', '215', '1 kg', '4.58', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(118, 4, 'Rui Fish After Cutting ±50 gm', 'rui-fish-after-cutting-50-gm-1-kg.png', '445', '365', '1 kg', '4.97', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(119, 4, 'Mola Fish Deshi ±15 gm', 'mola-fish-deshi-15-gm-250-gm.png', '135', '115', '250 gm', '3.56', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(120, 4, 'Kaski Fish ±15 gm', 'kaski-fish-15-gm-250-gm.png', '149', '125', '250 gm', '3.71', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(121, 4, 'Whole Hilsha Fish (Asto Ilish) ±40 gm', 'whole-hilsha-fish-asto-ilish-40-gm-500-gm.png', '599', '479', '500 gm', '4.07', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(122, 4, 'Telapiya Fish Processed ±50 gm', 'telapiya-fish-processed-50-gm-1-kg.png', '309', '285', '1 kg', '4.05', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(123, 4, 'Koi Fish Processed ±50 gm', 'koi-fish-processed-50-gm-1-kg.png', '475', '309', '1 kg', '3.01', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(124, 4, 'Gura Chingri (Shrimp) ±15 gm', 'gura-chingri-shrimp-15-gm-250-gm.png', '219', '159', '250 gm', '3.21', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(125, 4, 'Tatkini Fish ±30 gm', 'tatkini-fish-30-gm-500-gm.png', '209', '119', '500 gm', '4.66', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(126, 4, 'Shing Fish Processed ±30 gm', 'shing-fish-processed-30-gm-500-gm.png', '389', '299', '500 gm', '4.50', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(127, 4, 'Golda Chingri (Shrimp) 15-18 pcs ±30 gm', 'golda-chingri-shrimp-15-18-pcs-30-gm-500-gm.png', '575', '485', '500 gm', '3.63', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(128, 4, 'Rupchanda Fish Medium ±30 gm', 'rupchanda-fish-medium-30-gm-500-gm.png', '525', '419', '500 gm', '3.26', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(129, 4, 'Poa Fish ± 30 gm', 'poa-fish-30-gm-500-gm.png', '260', '209', '500 gm', '4.70', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(130, 4, 'Ayer Fish After Cutting ±30 gm', 'ayer-fish-after-cutting-30-gm-500-gm.png', '435', '359', '500 gm', '3.03', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(131, 4, 'Deshi Sarputi Fish ±30 gm', 'deshi-sarputi-fish-30-gm-500-gm.png', '249', '149', '500 gm', '3.65', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(132, 4, 'Puti Fish ±15 gm', 'puti-fish-15-gm-250-gm.png', '135', '125', '250 gm', '3.28', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(133, 4, 'Tengra Fish Deshi ±20 gm', 'tengra-fish-deshi-20-gm-400-gm.png', '275', '265', '400 gm', '4.82', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(134, 4, 'Baila Fish Medium ±30 gm', 'baila-fish-medium-30-gm-500-gm.png', '338', '315', '500 gm', '4.01', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(135, 4, 'Rui Fish Local After Cutting ±80 gm', 'rui-fish-local-after-cutting-80-gm-2-kg.png', '1000', '839', '2 kg', '3.70', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(136, 4, 'Catla Fish After Cutting ±70 gm', 'catla-fish-after-cutting-70-gm-15-kg.png', '774', '615', '1.5 kg', '4.17', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(137, 4, 'Magur Fish Processed ±30 gm', 'magur-fish-processed-30-gm-500-gm.png', '475', '399', '500 gm', '3.73', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(138, 4, 'Whole Hilsha Fish (Asto Ilish) ± 50 gm', 'whole-hilsha-fish-asto-ilish-50-gm-900-gm.png', '1179', '1049', '900 gm', '4.15', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(139, 4, 'Shol Fish Processed ±50 gm', 'shol-fish-processed-50-gm-1-kg.png', '865', '719', '1 kg', '3.52', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(140, 4, 'Carfu Fish After Cutting ±50 gm', 'carfu-fish-after-cutting-50-gm-1-kg.png', '399', '335', '1 kg', '3.35', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(141, 4, 'Bengal Fish Rohu Fish', 'bengal-fish-rohu-fish-1-kg.png', '560', '', '1 kg', '3.80', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(142, 4, 'Whole Hilsha Fish (Asto Ilish) ± 50 gm', 'whole-hilsha-fish-asto-ilish-50-gm-1-kg.png', '1349', '1219', '1 kg', '4.42', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(143, 4, 'Gulsha Fish Medium ±30 gm', 'gulsha-fish-medium-30-gm-500-gm.png', '390', '339', '500 gm', '4.14', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(144, 4, 'Koral Fish After Cutting ± 50 gm', 'koral-fish-after-cutting-50-gm-1-kg.png', '909', '', '1 kg', '3.42', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(145, 4, 'Boal Fish After Cutting ±50 gm', 'boal-fish-after-cutting-50-gm-1-kg.png', '745', '699', '1 kg', '4.03', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(146, 4, 'Tara Baim Fish ±30 gm', 'tara-baim-fish-30-gm-500-gm.png', '442', '379', '500 gm', '4.49', '2022-10-31 04:45:13', '2022-10-31 04:45:13'),
(147, 5, 'Beef Bone In ± 50 gm', 'beef-bone-in-50-gm-1-kg.png', '699', '', '1 kg', '3.87', '2022-10-31 04:46:19', '2022-10-31 04:46:19'),
(148, 5, 'Bengal Meat Beef Bone In ± 50 gm', 'bengal-meat-beef-bone-in-50-gm-1-kg.png', '795', '', '1 kg', '4.37', '2022-10-31 04:46:19', '2022-10-31 04:46:19'),
(149, 5, 'Beef Boneless ± 25 gm', 'beef-boneless-25-gm-500-gm.png', '459', '425', '500 gm', '4.55', '2022-10-31 04:46:19', '2022-10-31 04:46:19'),
(150, 5, 'Beef Liver (Kolija)', 'beef-liver-kolija-500-gm.png', '399', '349', '500 gm', '4.69', '2022-10-31 04:46:19', '2022-10-31 04:46:19'),
(151, 5, 'Beef Tripe (Vuri)', 'beef-tripe-vuri-1-kg.png', '359', '349', '1 kg', '3.07', '2022-10-31 04:46:19', '2022-10-31 04:46:19'),
(152, 5, 'Beef Ribs (Shinar Mangsho)', 'beef-ribs-shinar-mangsho-1-kg.png', '799', '699', '1 kg', '3.39', '2022-10-31 04:46:19', '2022-10-31 04:46:19'),
(153, 5, 'Mutton Paya', 'mutton-paya-10-pcs.png', '399', '359', '10 pcs', '4.51', '2022-10-31 04:46:19', '2022-10-31 04:46:19'),
(154, 5, 'Mutton Bone in (Khashi) ± 50 gm', 'mutton-bone-in-khashi-50-gm-1-kg.png', '1000', '959', '1 kg', '4.65', '2022-10-31 04:46:19', '2022-10-31 04:46:19'),
(155, 6, 'Tofu', 'tofu-150-gm.png', '69', '', '150 gm', '3.43', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(156, 6, 'King Bell Light Meat Tuna Vegetable Oil', 'king-bell-light-meat-tuna-vegetable-oil-185-gm.png', '220', '', '185 gm', '4.54', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(157, 6, 'Hibiscus Mushrooms Choice Whole Can', 'hibiscus-mushrooms-choice-whole-can-425-gm.png', '195', '179', '425 gm', '3.20', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(158, 6, 'King Bell Sardines In Tomato Sauce', 'king-bell-sardines-in-tomato-sauce-155-gm.png', '120', '', '155 gm', '3.65', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(159, 6, 'King Bell Tuna Salad In Tomato Sauce', 'king-bell-tuna-salad-in-tomato-sauce-170-gm.png', '220', '', '170 gm', '4.37', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(160, 6, 'Nautilus Lite Sandwich Tuna In Spring Water', 'nautilus-lite-sandwich-tuna-in-spring-water-165-gm.png', '231', '', '165 gm', '3.30', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(161, 6, 'Nautilus Lite Tuna Steak In Spring Water', 'nautilus-lite-tuna-steak-in-spring-water-165-gm.png', '255', '249', '165 gm', '4.28', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(162, 6, 'Saporito Red Kidney Beans', 'saporito-red-kidney-beans-400-gm.png', '193', '174', '400 gm', '4.83', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(163, 6, 'Nautilus Sandwich Tuna In Soybean Oil', 'nautilus-sandwich-tuna-in-soybean-oil-165-gm.png', '243', '', '165 gm', '3.84', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(164, 6, 'Nautilus Lite Tuna Chunk Soybean Oil', 'nautilus-lite-tuna-chunk-soybean-oil-165-gm.png', '231', '', '165 gm', '3.63', '2022-10-31 04:46:56', '2022-10-31 04:46:56'),
(165, 7, 'Kazi Farms Kitchen Loitta Dried Fish', 'kazi-farms-kitchen-loitta-dried-fish-125-gm.png', '240', '', '125 gm', '4.84', '2022-10-31 04:47:37', '2022-10-31 04:47:37'),
(166, 7, 'Shera Bangla 64 Balachaw', 'shera-bangla-64-balachaw-80-gm.png', '125', '', '80 gm', '3.24', '2022-10-31 04:47:37', '2022-10-31 04:47:37'),
(167, 7, 'Dhakaiya Dry Fish Kaski (Buy 2 Get 1 Mola Shutki 125 gm)', 'dhakaiya-dry-fish-kaski-buy-2-get-1-mola-shutki-125-gm-125-gm.png', '440', '', '125 gm', '4.18', '2022-10-31 04:47:37', '2022-10-31 04:47:37'),
(168, 7, 'Dhakaiya Loitta Shutki', 'dhakaiya-loitta-shutki-125-gm.png', '160', '', '125 gm', '3.42', '2022-10-31 04:47:37', '2022-10-31 04:47:37'),
(169, 7, 'Khaas Food Organic Churi Dry Fish', 'khaas-food-organic-churi-dry-fish-250-gm.png', '725', '', '250 gm', '4.83', '2022-10-31 04:47:37', '2022-10-31 04:47:37'),
(170, 7, 'Kazi Farms Kitchen Kechki Dried Fish', 'kazi-farms-kitchen-kechki-dried-fish-125-gm.png', '280', '', '125 gm', '4.69', '2022-10-31 04:47:37', '2022-10-31 04:47:37'),
(171, 7, 'Kazi Farms Kitchen Churi Dried Fish', 'kazi-farms-kitchen-churi-dried-fish-125-gm.png', '340', '', '125 gm', '4.46', '2022-10-31 04:47:37', '2022-10-31 04:47:37');

-- --------------------------------------------------------

--
-- Table structure for table `root_catagories`
--

CREATE TABLE `root_catagories` (
  `id` int NOT NULL,
  `root_catagory_title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `root_catagories`
--

INSERT INTO `root_catagories` (`id`, `root_catagory_title`, `image`, `createdAt`, `updatedAt`) VALUES
(1, 'Food', NULL, '2022-10-31 04:37:28', '2022-10-31 04:37:28');

-- --------------------------------------------------------

--
-- Table structure for table `sequelizemeta`
--

CREATE TABLE `sequelizemeta` (
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `sequelizemeta`
--

INSERT INTO `sequelizemeta` (`name`) VALUES
('20221027101124-create-root-catagory.js'),
('20221027110645-create-sub-catagory.js'),
('20221027110803-create-child-catagory.js'),
('20221027110804-create-products.js');

-- --------------------------------------------------------

--
-- Table structure for table `sub_catagories`
--

CREATE TABLE `sub_catagories` (
  `id` int NOT NULL,
  `root_catagory_id` int DEFAULT NULL,
  `sub_catagory_title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sub_catagories`
--

INSERT INTO `sub_catagories` (`id`, `root_catagory_id`, `sub_catagory_title`, `image`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'Fruits & Vegetables', 'fruits-vegetables.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(2, 1, 'Meat & Fish', 'meat-fish.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(3, 1, 'Cooking', 'cooking.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(4, 1, 'Sauces & Pickles', 'sauces-pickles.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(5, 1, 'Dairy & Eggs', 'dairy-eggs.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(6, 1, 'Breakfast', 'breakfast.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(7, 1, 'Snacks', 'snacks.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(8, 1, 'Beverages', 'beverages.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(9, 1, 'Baking', 'baking.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(10, 1, 'Frozen & Canned', 'frozen-canned.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(11, 1, 'Candy & Chocolate', 'candy-chocolate.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23'),
(12, 1, 'Diabetic Food', 'diabetic-food.png', '2022-10-30 04:48:23', '2022-10-30 04:48:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `child_catagories`
--
ALTER TABLE `child_catagories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub_catagory_id` (`sub_catagory_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `child_catagory_id` (`child_catagory_id`);

--
-- Indexes for table `root_catagories`
--
ALTER TABLE `root_catagories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sequelizemeta`
--
ALTER TABLE `sequelizemeta`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `sub_catagories`
--
ALTER TABLE `sub_catagories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `root_catagory_id` (`root_catagory_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `child_catagories`
--
ALTER TABLE `child_catagories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT for table `root_catagories`
--
ALTER TABLE `root_catagories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sub_catagories`
--
ALTER TABLE `sub_catagories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `child_catagories`
--
ALTER TABLE `child_catagories`
  ADD CONSTRAINT `child_catagories_ibfk_1` FOREIGN KEY (`sub_catagory_id`) REFERENCES `sub_catagories` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`child_catagory_id`) REFERENCES `child_catagories` (`id`);

--
-- Constraints for table `sub_catagories`
--
ALTER TABLE `sub_catagories`
  ADD CONSTRAINT `sub_catagories_ibfk_1` FOREIGN KEY (`root_catagory_id`) REFERENCES `root_catagories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
